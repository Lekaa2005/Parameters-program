package practise;


public class Parameters {
	int bkyear;          //in constructor can pass parameters
	String bkname;
	public Parameters(int year,String name) {
		bkyear=year;
		bkname=name;
	}	
	public static void main(String[] args) {
		Parameters obj=new Parameters(2001,"java");
		System.out.println(obj.bkname+"  "+obj.bkyear);
		
	}
}
